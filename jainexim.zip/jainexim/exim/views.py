#from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, redirect
#from .forms import ContactForm
from django.core.mail import send_mail, BadHeaderError
#from django.http import HttpResponse


def index(request):
    return render(request,'D:/QAR1549/Django/jain_exim/jainexim/template/exim/home.html')

def about_us(request):
    #
    send_mail('subject','kasa aahes','pushpakparatwar1008@gmail.com',['pushpakparatwar1008@gmail.com'])
    return render(request,'D:/QAR1549/Django/jain_exim/jainexim/template/exim/about-us.html')

def products(request):
    return render(request,'D:/QAR1549/Django/jain_exim/jainexim/template/exim/services.html')

def contact_us(request):
    return render(request,'D:/QAR1549/Django/jain_exim/jainexim/template/exim/contact-us.html')
