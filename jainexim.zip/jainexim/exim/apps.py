from django.apps import AppConfig


class EximConfig(AppConfig):
    name = 'exim'
